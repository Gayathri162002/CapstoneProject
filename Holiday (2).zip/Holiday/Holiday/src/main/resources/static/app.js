document.addEventListener('DOMContentLoaded', () => {
    fetchRooms();

    document.getElementById('room-form').addEventListener('submit', event => {
        event.preventDefault();
        addRoom();
    });
});

function fetchRooms() {
    fetch('/api/rooms')
        .then(response => response.json())
        .then(data => {
            const roomList = document.getElementById('room-list');
            roomList.innerHTML = '';
            data.forEach(room => {
                const roomElement = document.createElement('div');
                roomElement.textContent = `Type: ${room.type}, Available: ${room.isAvailable}`;
                roomList.appendChild(roomElement);
            });
        });
}

function addRoom() {
    const type = document.getElementById('type').value;
    const isAvailable = document.getElementById('isAvailable').checked;

    fetch('/api/rooms', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ type, isAvailable })
    })
    .then(response => response.json())
    .then(() => {
        fetchRooms();
    });
}
