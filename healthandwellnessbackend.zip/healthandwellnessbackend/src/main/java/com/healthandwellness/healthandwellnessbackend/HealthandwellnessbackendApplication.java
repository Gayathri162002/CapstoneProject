package com.healthandwellness.healthandwellnessbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HealthandwellnessbackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(HealthandwellnessbackendApplication.class, args);
	}

}
