package com.healthandwellness.healthandwellnessbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthandwellnessbackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
